package com.example.dao;

import com.example.model.Project;

public class DaoImpl extends Dao {
    @Override
    public <T> void persist(T entity) {
        getCurrentSessionAndOpenTransation().persist(entity);
        closeTransaction();
    }

    @Override
    public <T> void update(T entity) {
        getCurrentSessionAndOpenTransation().update(entity);
        closeTransaction();
    }

    @Override
    public Object findById(int id) {
        return getCurrentSessionAndOpenTransation().get(Project.class, id);
    }

    @Override
    public <T> void delete(T entity) {
        getCurrentSessionAndOpenTransation().delete(entity);
        closeTransaction();
    }
}
