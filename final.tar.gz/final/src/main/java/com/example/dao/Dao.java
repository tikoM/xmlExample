package com.example.dao;

import com.example.model.Project;
import com.example.model.Task;
import com.example.model.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.transform.Transformers;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.List;

public abstract class Dao {
    private static SessionFactory sessionFactory =
            sessionFactory = new Configuration().configure("/sql/hibernate.cfg.xml").buildSessionFactory();

    private Transaction currentTransaction;

    private Session currentSession;

    private SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    private void openCurrentSessionWithTransaction() {
        currentSession = getSessionFactory().getCurrentSession();
        currentTransaction = currentSession.beginTransaction();
    }

    Session getCurrentSessionAndOpenTransation() {
        openCurrentSessionWithTransaction();
        return currentSession;
    }

    void closeTransaction() {
        currentTransaction.commit();
    }

    public abstract <T> void persist(T entity);

    public abstract <T> void update(T entity);

    public abstract Object findById(int id);

    public abstract <T> void delete(T entity);

    public List<Project> getAllProjects() {
        return sessionFactory.openSession().createCriteria(Project.class).list();
    }

    public List<User> getAllUsers() {
        return sessionFactory.openSession().createCriteria(User.class).list();
    }

    public List<Task> getAllTasks() {
        return sessionFactory.openSession().createCriteria(Task.class).list();
    }

}
