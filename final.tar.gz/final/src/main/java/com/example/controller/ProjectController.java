package com.example.controller;

import com.example.dao.Dao;
import com.example.dao.DaoImpl;
import com.example.model.Project;
import com.example.model.Task;
import com.example.model.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProjectController {

    private Dao dao;

    public ProjectController(DaoImpl dao) {
        this.dao = dao;
    }

    @RequestMapping(value = "/task", method = RequestMethod.POST)
    Task addTask(@RequestBody Task task) {
        dao.persist(task);
        return task;
    }

    @RequestMapping(value = "/task", method = RequestMethod.GET)
    List<Task> getAllTasks() {
        return dao.getAllTasks();
    }

    @RequestMapping(value = "/user", method = RequestMethod.POST)
    User addUser(@RequestBody User user) {
        dao.persist(user);
        return null;
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    List<User> getAllUsers() {
        return dao.getAllUsers();
    }

    @RequestMapping(value = "/project", method = RequestMethod.POST)
    Project addProject(@RequestBody Project project) {
        dao.persist(project);
        return null;
    }

    @RequestMapping(value = "/project", method = RequestMethod.GET)
    List<Project> getAllProjects() {
        return dao.getAllProjects();
    }


    private void validateUser(Integer userId) {
        User user = (User) this.dao.findById(userId);
        if (user == null) {

        }
    }
}