$(document).ready(function () {
    $('#submitUserId').click(function () {
        $.ajax({
            url: '/user',
            type: 'POST',
            data: JSON.stringify({name: $('#userNameId').val(), email: $('#emailNameId')}),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function(msg) {
                window.close();
            }
        });
    });
});


