
$(document).ready(function () {
    $('#submitId').click(function () {
        $.ajax({
            url: '/project',
            type: 'POST',
            data: JSON.stringify({name: $('#projectNameId').val()}),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function(msg) {
                window.close();
            }
        });
    });
});
