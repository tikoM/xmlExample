$(document).ready(function () {
    $.get("/user", function (data, status) {
        createUserDropDown(data)
    });
});

$(document).ready(function () {
    $('#submitTaskId').click(function () {
        let url = document.URL;
        let project = getParameterByName("project");
        let dropdown =$("#userDropDownId");
        $.ajax({
            url: '/task',
            type: 'POST',
            data: JSON.stringify({
                key: $('#taskNameId').val(),
                description: $('#taskDeskriptionId').val(),
                user: dropdown.val(),
                project: {id:getParameterByName('id'), name: getParameterByName('name')}
            }),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function (msg) {
                window.close();
            }
        });
    });
});

function createUserDropDown(users) {
    users.forEach((item, index) => {
        let dropDownRow = '<option value="' + item + '">' + item.name + '</option>';
        $('#userDropDownId').append(dropDownRow);
    });
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}