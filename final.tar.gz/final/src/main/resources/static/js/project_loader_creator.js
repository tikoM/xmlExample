$(document).ready(function () {
    $.get("/project", function (data, status) {
        createProjectRow(data)
    });
});

function createProjectRow(projects) {
    projects.forEach((item, index) => {
        let tableRow = '<tr>' +
            '<th scope="row">' + index + '</th>' +
            '<td><a href="/task_form.html?name=' + item.name + '&id='
            + item.id + '">' + item.name + '</a></td>' +
            '</tr>';
        $('#projectTBodyId').append(tableRow);
    });
}